import "./../styles/input.scss";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { useState } from "react";

export const Password = ({ layoutType, error, label, onChange, value }) => {
  const [reveal, setReveal] = useState(false);
  return (
    <div className="input-container">
      <label className={layoutType}>
        {label}
        <span className="icon-container">
          <input
            type={reveal ? "text" : "password"}
            className="input field"
            onChange={onChange}
            value={value}
          />
          <span
            className="icon"
            onClick={(ev) => setReveal((reveal) => !reveal)}
          >
            {reveal ? <Visibility /> : <VisibilityOff />}
          </span>
        </span>
      </label>
      {error && <small className="error">{error}</small>}
    </div>
  );
};
