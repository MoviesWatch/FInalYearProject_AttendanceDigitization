import "./../styles/table.scss";
export const Table = ({ titles, datas, keys }) => {
  return (
    <div className="table-container">
      <table>
        <thead>
          <tr>
            <th>S.No</th>
            {titles.map((title) => (
              <th>{title}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {datas.map((data, index) => (
            <tr>
              <td>{index + 1}</td>
              {keys.map((key) => (
                <td>{data[key]}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {datas.length > 20 && (
        <div className="pagination">
          <button>Prev</button>
          <div className="page-num">
            <input type="number" /> / <span>12</span>
          </div>
          <button>Next</button>
        </div>
      )}
    </div>
  );
};
