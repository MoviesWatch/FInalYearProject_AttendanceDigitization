import "./../styles/input.scss";
export const Select = ({ layoutType, error, label, options, onChange }) => {
  return (
    <div className="input-container">
      <label className={layoutType}>
        {label}
        <select className="input field" onChange={onChange}>
          <option value="" selected>
            --select--
          </option>
          {options.map((option) => (
            <option value={option[1]}>{option[0]}</option>
          ))}
        </select>
      </label>
      {error && <small className="error">{error}</small>}
    </div>
  );
};
