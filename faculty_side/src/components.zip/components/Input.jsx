import "./../styles/input.scss";
export const Input = ({
  type,
  layoutType,
  isField,
  error,
  label,
  onChange,
  value,
}) => {
  return (
    <div className="input-container">
      <label className={layoutType}>
        {label}
        <input
          type={type}
          className={`input ${isField && "field"}`}
          onChange={onChange}
          value={value}
        />
      </label>
      {error && <small className="error">{error}</small>}
    </div>
  );
};
