import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export const ProtectedRoute = ({ route, login }) => {
  const navigate = useNavigate();
  const user = sessionStorage.getItem("user");
  useEffect(() => {
    if (!user) navigate("/login", { replace: true });
    if (user && login) navigate("/", { replace: true });
  }, [user]);
  return route;
};
